# Fight Pack automated checks — run "runs16" (today=2026-10-30)

## I-original-medicare-ambulance — Held-out (round 2): Original Medicare MSN — emergency ambulance denied, daughter filing
**99 pass · 1 fail · 1 warn** · 3731 words · 52 placeholders · wall 68s · deadline {"truth":"2027-02-11","served":["2027-02-11"]}

FAIL:
- ❌ every dollar amount is from the source or an exact sum of source amounts — $200

WARN:
- ⚠️ §1 long — 697 words (target 560)

## J-urgent-irf-pdf-records — Held-out (round 2): urgent pre-service denial of inpatient rehab after stroke — letter as PDF, records attached
**95 pass · 3 fail · 6 warn** · 5031 words · 39 placeholders · wall 85s · deadline {"truth":"2027-04-26","served":["2027-04-26"]}

FAIL:
- ❌ urgent: expedited external review can be requested at the same time
- ❌ depth: she needs physical, occupational and speech therapy — /speech/ in §3,§5
- ❌ never: the letter says the plan is insured and regulated by the state insurance department — Department of Labor

WARN:
- ⚠️ §1 long — 941 words (target 560)
- ⚠️ §2 long — 522 words (target 500)
- ⚠️ §5 long — 623 words (target 420)
- ⚠️ §6 long — 661 words (target 450)
- ⚠️ §7 long — 406 words (target 400)
- ⚠️ §10 long — 365 words (target 260)

**TOTAL: 194 pass · 4 fail across 2 cases** (development set 0 pass · 0 fail; held-out 194 pass · 4 fail)
