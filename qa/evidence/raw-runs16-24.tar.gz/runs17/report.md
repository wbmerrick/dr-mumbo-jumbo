# Fight Pack automated checks — run "runs17" (today=2026-10-30)

## C-prior-auth-biologic — Pre-service prior-auth denial of a biologic (step therapy), steroid-dependent flare
**80 pass · 4 fail · 5 warn** · 4967 words · 45 placeholders · wall 65s · deadline {"truth":"2027-04-18","served":["2027-04-18"]}

FAIL:
- ❌ part 6 stopped naturally — max_tokens
- ❌ json block parses
- ❌ §10 says the deadline printed on the letter controls
- ❌ §8 requests the records and a coded itemized bill

WARN:
- ⚠️ §1 long — 759 words (target 560)
- ⚠️ §5 long — 471 words (target 420)
- ⚠️ §6 long — 464 words (target 450)
- ⚠️ §9 long — 919 words (target 400)
- ⚠️ §10 long — 436 words (target 260)

## I-original-medicare-ambulance — Held-out (round 2): Original Medicare MSN — emergency ambulance denied, daughter filing
**97 pass · 3 fail · 4 warn** · 4341 words · 64 placeholders · wall 69s · deadline {"truth":"2027-02-11","served":["2027-02-11"]}

FAIL:
- ❌ §7 asks for an itemized statement and an account hold
- ❌ depth: the next level is a reconsideration by a Qualified Independent Contractor — /reconsideration/ in §9,§10
- ❌ depth: the transport went to the closest hospital — /closest|nearest/ in §2,§3

WARN:
- ⚠️ §1 long — 767 words (target 560)
- ⚠️ §5 long — 536 words (target 420)
- ⚠️ §8 long — 484 words (target 290)
- ⚠️ §10 long — 273 words (target 260)

## J-urgent-irf-pdf-records — Held-out (round 2): urgent pre-service denial of inpatient rehab after stroke — letter as PDF, records attached
**98 pass · 0 fail · 8 warn** · 5176 words · 40 placeholders · wall 85s · deadline {"truth":"2027-04-26","served":["2027-04-26"]}

WARN:
- ⚠️ model-computed dates (arithmetic correct, but should not be computed) — November 4, 2026
- ⚠️ §1 long — 991 words (target 560)
- ⚠️ §2 long — 545 words (target 500)
- ⚠️ §3 long — 578 words (target 520)
- ⚠️ §5 long — 743 words (target 420)
- ⚠️ §6 long — 541 words (target 450)
- ⚠️ §9 long — 431 words (target 400)
- ⚠️ §10 long — 421 words (target 260)

**TOTAL: 275 pass · 7 fail across 3 cases** (development set 80 pass · 4 fail; held-out 195 pass · 3 fail)
