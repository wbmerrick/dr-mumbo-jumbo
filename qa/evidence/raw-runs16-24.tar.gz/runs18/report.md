# Fight Pack automated checks — run "runs18" (today=2026-10-30)

## C-prior-auth-biologic — Pre-service prior-auth denial of a biologic (step therapy), steroid-dependent flare
**102 pass · 2 fail · 4 warn** · 4521 words · 54 placeholders · wall 69s · deadline {"truth":"2027-04-18","served":["2027-04-18"]}

FAIL:
- ❌ cross-references point at the right section — and to write and sign the expedited appeal letter → section 3
- ❌ never: (audit) the notice lists no exceptions — none is attributed to RX-ST-114 — RX-ST-114 and tell me if it includes exception

WARN:
- ⚠️ §1 long — 819 words (target 560)
- ⚠️ §5 long — 578 words (target 420)
- ⚠️ §9 long — 424 words (target 400)
- ⚠️ §10 long — 414 words (target 260)

## I-original-medicare-ambulance — Held-out (round 2): Original Medicare MSN — emergency ambulance denied, daughter filing
**99 pass · 1 fail · 2 warn** · 3574 words · 46 placeholders · wall 55s · deadline {"truth":"2027-02-11","served":["2027-02-11"]}

FAIL:
- ❌ §5 maps criteria and prepares for push-back

WARN:
- ⚠️ §1 long — 596 words (target 560)
- ⚠️ §10 long — 369 words (target 260)

## J-urgent-irf-pdf-records — Held-out (round 2): urgent pre-service denial of inpatient rehab after stroke — letter as PDF, records attached
**97 pass · 1 fail · 6 warn** · 4955 words · 42 placeholders · wall 74s · deadline {"truth":"2027-04-26","served":["2027-04-26"]}

FAIL:
- ❌ never: the letter says the plan is insured and regulated by the state insurance department — Department of Labor

WARN:
- ⚠️ §1 long — 917 words (target 560)
- ⚠️ §2 long — 614 words (target 500)
- ⚠️ §3 long — 545 words (target 520)
- ⚠️ §5 long — 698 words (target 420)
- ⚠️ §9 long — 487 words (target 400)
- ⚠️ §10 long — 354 words (target 260)

**TOTAL: 298 pass · 4 fail across 3 cases** (development set 102 pass · 2 fail; held-out 196 pass · 2 fail)
